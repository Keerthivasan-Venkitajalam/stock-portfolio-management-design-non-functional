document.addEventListener("DOMContentLoaded", function () {

    document.getElementById("dashbrd-name").innerText = ""; 

    const payHistory = document.getElementById("payHistory");
    const stocks = [
        { date: "2024-05-28", icon: "🇮🇳", stockName: "Reliance Industries", amount: 1500, rate: 2, marketCap: 18.5, transactionType: "Buy" },
        { date: "2024-05-27", icon: "🇮🇳", stockName: "Tata Consultancy Services", amount: 1000, rate: 1.5, marketCap: 13.5, transactionType: "Sell" },
        { date: "2024-05-26", icon: "🇮🇳", stockName: "Infosys", amount: 800, rate: 1, marketCap: 6.5, transactionType: "Buy" },
        { date: "2024-05-25", icon: "🇮🇳", stockName: "HDFC Bank", amount: 1200, rate: 2.5, marketCap: 12, transactionType: "Buy" },
        { date: "2024-05-24", icon: "🇮🇳", stockName: "ICICI Bank", amount: 900, rate: 1.8, marketCap: 8.5, transactionType: "Sell" },
        { date: "2024-05-23", icon: "🇮🇳", stockName: "State Bank of India", amount: 700, rate: 1.2, marketCap: 5.7, transactionType: "Buy" },
        { date: "2024-05-22", icon: "🇮🇳", stockName: "Bharti Airtel", amount: 600, rate: 1, marketCap: 6.8, transactionType: "Sell" },
        { date: "2024-05-21", icon: "🇮🇳", stockName: "Hindustan Unilever", amount: 1500, rate: 2.2, marketCap: 14.5, transactionType: "Buy" },
        { date: "2024-05-20", icon: "🇮🇳", stockName: "ITC Limited", amount: 400, rate: 0.8, marketCap: 4, transactionType: "Buy" },
        { date: "2024-05-19", icon: "🇮🇳", stockName: "Coal India", amount: 300, rate: 0.6, marketCap: 2.5, transactionType: "Sell" },
        { date: "2024-05-18", icon: "🇮🇳", stockName: "Sun Pharma", amount: 1100, rate: 1.9, marketCap: 10, transactionType: "Buy" },
        { date: "2024-05-17", icon: "🇮🇳", stockName: "Wipro", amount: 500, rate: 0.9, marketCap: 4.8, transactionType: "Sell" },
        { date: "2024-05-16", icon: "🇮🇳", stockName: "Bajaj Auto", amount: 800, rate: 1.6, marketCap: 7.2, transactionType: "Buy" },
        { date: "2024-05-15", icon: "🇮🇳", stockName: "Maruti Suzuki", amount: 1400, rate: 2.4, marketCap: 11.8, transactionType: "Sell" },
        { date: "2024-05-14", icon: "🇮🇳", stockName: "NTPC", amount: 600, rate: 1.1, marketCap: 5.3, transactionType: "Buy" },
        { date: "2024-05-13", icon: "🇮🇳", stockName: "Power Grid", amount: 700, rate: 1.3, marketCap: 6, transactionType: "Buy" },
    ];

    stocks.forEach(stock => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${stock.date}</td>
            <td>${stock.icon}</td>
            <td>${stock.stockName}</td>
            <td>₹${(stock.amount * 75).toFixed(2)}</td>
            <td>${stock.rate}%</td>
            <td>₹${(stock.marketCap * 75).toFixed(2)} billion</td>
            <td>${stock.transactionType}</td>
        `;
        payHistory.appendChild(row);
    });
});
